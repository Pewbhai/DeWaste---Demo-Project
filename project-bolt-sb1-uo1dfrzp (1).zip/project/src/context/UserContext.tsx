import { createContext, useState, useEffect, ReactNode, useContext } from 'react';
import { AuthContext } from './AuthContext';

interface RecyclingActivity {
  id: string;
  date: string;
  type: string;
  weight: number;
  tokensEarned: number;
  status: 'pending' | 'verified' | 'rejected';
  imageUrl?: string;
}

interface UserStats {
  totalRecycled: number;
  totalEarned: number;
  impactScore: number;
  level: number;
  nextLevelThreshold: number;
}

interface UserContextType {
  recyclingHistory: RecyclingActivity[];
  stats: UserStats;
  tokenBalance: number;
  addRecyclingActivity: (activity: Omit<RecyclingActivity, 'id'>) => void;
}

const defaultStats: UserStats = {
  totalRecycled: 0,
  totalEarned: 0,
  impactScore: 0,
  level: 1,
  nextLevelThreshold: 100,
};

const defaultContext: UserContextType = {
  recyclingHistory: [],
  stats: defaultStats,
  tokenBalance: 0,
  addRecyclingActivity: () => {},
};

export const UserContext = createContext<UserContextType>(defaultContext);

interface UserProviderProps {
  children: ReactNode;
}

export const UserProvider = ({ children }: UserProviderProps) => {
  const { status } = useContext(AuthContext);
  const [recyclingHistory, setRecyclingHistory] = useState<RecyclingActivity[]>([]);
  const [stats, setStats] = useState<UserStats>(defaultStats);
  const [tokenBalance, setTokenBalance] = useState(0);

  useEffect(() => {
    if (status === 'authenticated') {
      // Mock data
      const mockHistory: RecyclingActivity[] = [
        {
          id: '1',
          date: '2025-03-15T10:30:00Z',
          type: 'Plastic',
          weight: 2.5,
          tokensEarned: 25,
          status: 'verified',
          imageUrl: 'https://images.pexels.com/photos/802221/pexels-photo-802221.jpeg?auto=compress&cs=tinysrgb&w=600'
        },
        {
          id: '2',
          date: '2025-03-10T14:45:00Z',
          type: 'Glass',
          weight: 3.2,
          tokensEarned: 32,
          status: 'verified',
          imageUrl: 'https://images.pexels.com/photos/5029859/pexels-photo-5029859.jpeg?auto=compress&cs=tinysrgb&w=600'
        },
        {
          id: '3',
          date: '2025-03-05T09:15:00Z',
          type: 'Paper',
          weight: 1.8,
          tokensEarned: 18,
          status: 'verified',
          imageUrl: 'https://images.pexels.com/photos/5677798/pexels-photo-5677798.jpeg?auto=compress&cs=tinysrgb&w=600'
        },
        {
          id: '4',
          date: '2025-03-01T16:20:00Z',
          type: 'Electronic Waste',
          weight: 4.5,
          tokensEarned: 90,
          status: 'verified',
          imageUrl: 'https://images.pexels.com/photos/6976094/pexels-photo-6976094.jpeg?auto=compress&cs=tinysrgb&w=600'
        }
      ];

      const mockStats: UserStats = {
        totalRecycled: 12,
        totalEarned: 165,
        impactScore: 73,
        level: 2,
        nextLevelThreshold: 250,
      };

      setRecyclingHistory(mockHistory);
      setStats(mockStats);
      setTokenBalance(165);
    } else {
      // Reset data
      setRecyclingHistory([]);
      setStats(defaultStats);
      setTokenBalance(0);
    }
  }, [status]);

  const addRecyclingActivity = (activity: Omit<RecyclingActivity, 'id'>) => {
    const newActivity: RecyclingActivity = {
      ...activity,
      id: Date.now().toString(),
    };

    setRecyclingHistory([newActivity, ...recyclingHistory]);
    
    // Update stats
    setStats({
      ...stats,
      totalRecycled: stats.totalRecycled + activity.weight,
      totalEarned: stats.totalEarned + activity.tokensEarned,
      impactScore: stats.impactScore + Math.floor(activity.weight * 5),
    });

    // Update token balance
    setTokenBalance(tokenBalance + activity.tokensEarned);
  };

  return (
    <UserContext.Provider
      value={{
        recyclingHistory,
        stats,
        tokenBalance,
        addRecyclingActivity,
      }}
    >
      {children}
    </UserContext.Provider>
  );
};