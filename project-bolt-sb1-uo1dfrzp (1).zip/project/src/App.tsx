import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { useState, useEffect } from 'react';
import HomePage from './pages/Home';
import DashboardPage from './pages/Dashboard';
import RecyclingPage from './pages/Recycling';
import WalletPage from './pages/Wallet';
import ProfilePage from './pages/Profile';
import AuthPage from './pages/Auth';
import NotFoundPage from './pages/NotFound';
import { AuthProvider } from './context/AuthContext';
import { UserProvider } from './context/UserContext';

function App() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate initial data loading
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-teal-50 to-green-50">
        <div className="flex flex-col items-center">
          <div className="w-16 h-16 border-t-4 border-teal-500 border-solid rounded-full animate-spin mb-4"></div>
          <p className="text-teal-800 text-lg font-medium">Loading DeWaste...</p>
        </div>
      </div>
    );
  }

  return (
    <AuthProvider>
      <UserProvider>
        <Router>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/recycling" element={<RecyclingPage />} />
            <Route path="/wallet" element={<WalletPage />} />
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="/auth/:type" element={<AuthPage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </Router>
      </UserProvider>
    </AuthProvider>
  );
}

export default App;