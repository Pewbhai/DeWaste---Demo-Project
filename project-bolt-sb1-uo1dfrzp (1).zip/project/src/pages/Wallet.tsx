import { useContext } from 'react';
import { Navigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import DashboardLayout from '../components/layout/DashboardLayout';
import TokenManagement from '../components/wallet/TokenManagement';

const WalletPage = () => {
  const { status } = useContext(AuthContext);

  if (status === 'unauthenticated') {
    return <Navigate to="/auth/login" replace />;
  }

  return (
    <DashboardLayout pageTitle="Token Wallet">
      <div className="max-w-4xl mx-auto">
        <p className="text-gray-600 mb-8">
          Manage your USDC tokens earned from recycling activities. You can view your balance, transaction history, and convert tokens to other currencies.
        </p>
        
        <TokenManagement />
      </div>
    </DashboardLayout>
  );
};

export default WalletPage;