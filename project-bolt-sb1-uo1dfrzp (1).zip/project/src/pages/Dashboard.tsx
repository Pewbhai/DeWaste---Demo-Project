import { useContext } from 'react';
import { Navigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import DashboardLayout from '../components/layout/DashboardLayout';
import RecyclingStats from '../components/dashboard/RecyclingStats';
import RecyclingHistory from '../components/dashboard/RecyclingHistory';

const DashboardPage = () => {
  const { status } = useContext(AuthContext);

  if (status === 'unauthenticated') {
    return <Navigate to="/auth/login" replace />;
  }

  return (
    <DashboardLayout pageTitle="Dashboard">
      <div className="space-y-8">
        <RecyclingStats />
        <RecyclingHistory />
      </div>
    </DashboardLayout>
  );
};

export default DashboardPage;