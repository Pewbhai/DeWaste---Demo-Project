import { useContext, useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import AuthForm from '../components/auth/AuthForm';

const AuthPage = () => {
  const { status } = useContext(AuthContext);
  
  useEffect(() => {
    // Update document title
    document.title = 'DeWaste | Sign In';
  }, []);

  if (status === 'authenticated') {
    return <Navigate to="/dashboard" replace />;
  }

  return <AuthForm />;
};

export default AuthPage;