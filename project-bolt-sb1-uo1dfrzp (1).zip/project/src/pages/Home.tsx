import { useContext } from 'react';
import { Link } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import Hero from '../components/home/Hero';
import HowItWorks from '../components/home/HowItWorks';
import Features from '../components/home/Features';
import RewardsSystem from '../components/home/RewardsSystem';
import Testimonials from '../components/home/Testimonials';
import Newsletter from '../components/home/Newsletter';
import CTA from '../components/home/CTA';

const HomePage = () => {
  const { status } = useContext(AuthContext);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow">
        <Hero />
        <HowItWorks />
        <Features />
        <RewardsSystem />
        <Testimonials />
        {status !== 'authenticated' && <CTA />}
        <Newsletter />
      </main>

      <Footer />
    </div>
  );
};

export default HomePage;