import { useContext } from 'react';
import { Navigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import DashboardLayout from '../components/layout/DashboardLayout';
import UploadForm from '../components/recycling/UploadForm';

const RecyclingPage = () => {
  const { status } = useContext(AuthContext);

  if (status === 'unauthenticated') {
    return <Navigate to="/auth/login" replace />;
  }

  return (
    <DashboardLayout pageTitle="Recycle & Earn">
      <div className="max-w-3xl mx-auto">
        <p className="text-gray-600 mb-8">
          Upload proof of your recycling activities to earn tokens. Our system will verify your submission and add tokens to your balance.
        </p>
        
        <UploadForm />
      </div>
    </DashboardLayout>
  );
};

export default RecyclingPage;