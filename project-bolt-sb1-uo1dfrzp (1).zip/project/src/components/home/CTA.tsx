import { Link } from 'react-router-dom';
import Button from '../ui/Button';

const CTA = () => {
  return (
    <section className="py-16 md:py-24 bg-teal-800 text-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Turn Your Waste Into Earnings?
          </h2>
          <p className="text-lg text-teal-100 mb-10 max-w-2xl mx-auto">
            Join thousands of conscious recyclers who are making a difference for the planet while earning rewards. Your sustainable journey starts here.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-md mx-auto">
            <Link to="/auth/register">
              <Button variant="white" fullWidth>
                Create Account
              </Button>
            </Link>
            <Link to="/auth/login">
              <Button variant="outline" fullWidth>
                Sign In
              </Button>
            </Link>
          </div>
          
          <div className="mt-12 pt-12 border-t border-teal-700">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="font-bold text-3xl text-white mb-2">100%</div>
                <p className="text-teal-200">Secure Blockchain Validation</p>
              </div>
              <div className="text-center">
                <div className="font-bold text-3xl text-white mb-2">10M+</div>
                <p className="text-teal-200">Tokens Already Distributed</p>
              </div>
              <div className="text-center">
                <div className="font-bold text-3xl text-white mb-2">15K+</div>
                <p className="text-teal-200">Registered Recyclers</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTA;