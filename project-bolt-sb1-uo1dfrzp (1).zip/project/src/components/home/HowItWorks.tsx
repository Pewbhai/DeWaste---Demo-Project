import { Camera, CheckCircle, CreditCard, Recycle } from 'lucide-react';

const HowItWorks = () => {
  const steps = [
    {
      icon: Recycle,
      title: 'Collect Recyclables',
      description: 'Gather recyclable materials like plastic, paper, glass, or electronic waste.',
      color: 'text-green-500',
      bgColor: 'bg-green-100',
    },
    {
      icon: Camera,
      title: 'Upload Proof',
      description: 'Take a photo of your recycling or use RFID tags for larger collections.',
      color: 'text-blue-500',
      bgColor: 'bg-blue-100',
    },
    {
      icon: CheckCircle,
      title: 'Get Verified',
      description: 'Our smart contracts automatically validate your recycling activity.',
      color: 'text-indigo-500',
      bgColor: 'bg-indigo-100',
    },
    {
      icon: CreditCard,
      title: 'Earn Tokens',
      description: 'Receive USDC tokens based on the quantity and type of materials recycled.',
      color: 'text-teal-500',
      bgColor: 'bg-teal-100',
    },
  ];

  return (
    <section id="how-it-works" className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            How DeWaste Works
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Our platform makes it easy to turn your recycling efforts into earnings in just four simple steps.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div
              key={index}
              className="bg-white rounded-xl shadow-md p-6 transition-transform hover:scale-105"
            >
              <div className={`${step.bgColor} p-4 rounded-full inline-block mb-6`}>
                <step.icon className={`h-8 w-8 ${step.color}`} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">{step.title}</h3>
              <p className="text-gray-600">{step.description}</p>
              <div className="mt-6">
                <span className="bg-gray-200 text-gray-800 text-sm font-medium py-1 px-3 rounded-full">
                  Step {index + 1}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Connecting lines between cards - visible only on desktop */}
        <div className="hidden lg:block relative">
          <div className="absolute top-[-120px] left-[25%] w-[50%] border-t-2 border-dashed border-gray-300"></div>
          <div className="absolute top-[-120px] left-[25%] h-8 border-l-2 border-dashed border-gray-300"></div>
          <div className="absolute top-[-120px] left-[75%] h-8 border-l-2 border-dashed border-gray-300"></div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;