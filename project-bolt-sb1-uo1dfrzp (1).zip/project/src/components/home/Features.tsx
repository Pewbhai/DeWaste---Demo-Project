import { Shield, TrendingUp, Coins, BarChart, Smartphone, Globe } from 'lucide-react';

const Features = () => {
  const featuresList = [
    {
      icon: Shield,
      title: 'Secure Blockchain Validation',
      description: 'All recycling activity is securely validated and recorded on the Solana blockchain, ensuring transparency and immutability.',
    },
    {
      icon: TrendingUp,
      title: 'Real-time Token Issuance',
      description: 'Earn USDC tokens instantly as your recycling efforts are verified through our smart contract system.',
    },
    {
      icon: Coins,
      title: 'Flexible Token Utilization',
      description: 'Convert your earned tokens to fiat currency or use them within our partner ecosystem for exclusive discounts and services.',
    },
    {
      icon: BarChart,
      title: 'Track Your Impact',
      description: 'Monitor your recycling stats and environmental impact with detailed analytics and progress tracking.',
    },
    {
      icon: Smartphone,
      title: 'Easy Mobile Verification',
      description: 'Simply take a photo of your recyclables or use RFID tags for seamless verification from anywhere.',
    },
    {
      icon: Globe,
      title: 'Global Impact Community',
      description: 'Join a worldwide network of environmentally conscious individuals making a real difference for our planet.',
    },
  ];

  return (
    <section id="features" className="py-16 md:py-24 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Powerful Platform Features
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            DeWaste combines cutting-edge blockchain technology with environmental sustainability to create a seamless recycling rewards ecosystem.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuresList.map((feature, index) => (
            <div
              key={index}
              className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow p-6 border border-gray-100"
            >
              <feature.icon className="h-10 w-10 text-teal-500 mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-3">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;