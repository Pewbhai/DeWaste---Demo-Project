import { useState } from 'react';
import Button from '../ui/Button';

const Newsletter = () => {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [message, setMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setStatus('loading');
    // Simulate API call
    setTimeout(() => {
      setStatus('success');
      setMessage('Thanks for subscribing! Check your email for updates.');
      setEmail('');
    }, 1500);
  };

  return (
    <section className="py-16 md:py-24 bg-teal-50">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Stay Updated with DeWaste News
          </h2>
          <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
            Subscribe to our newsletter for the latest updates on features, rewards, and environmental impact stories.
          </p>

          <form onSubmit={handleSubmit} className="max-w-md mx-auto">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="flex-grow">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                  required
                />
              </div>
              <Button
                type="submit"
                variant="primary"
                disabled={status === 'loading'}
                className="whitespace-nowrap"
              >
                {status === 'loading' ? 'Subscribing...' : 'Subscribe'}
              </Button>
            </div>
            
            {status === 'success' && (
              <div className="mt-4 text-green-600 text-sm">{message}</div>
            )}
            
            {status === 'error' && (
              <div className="mt-4 text-red-600 text-sm">{message}</div>
            )}

            <p className="mt-4 text-sm text-gray-500">
              We respect your privacy. Unsubscribe at any time.
            </p>
          </form>

          <div className="mt-12 flex flex-wrap justify-center gap-8">
            <img src="https://images.pexels.com/photos/6146970/pexels-photo-6146970.jpeg?auto=compress&cs=tinysrgb&w=150" alt="Newsletter image" className="h-16 object-contain rounded-lg shadow-sm" />
            <img src="https://images.pexels.com/photos/5029859/pexels-photo-5029859.jpeg?auto=compress&cs=tinysrgb&w=150" alt="Newsletter image" className="h-16 object-contain rounded-lg shadow-sm" />
            <img src="https://images.pexels.com/photos/6963589/pexels-photo-6963589.jpeg?auto=compress&cs=tinysrgb&w=150" alt="Newsletter image" className="h-16 object-contain rounded-lg shadow-sm" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Newsletter;