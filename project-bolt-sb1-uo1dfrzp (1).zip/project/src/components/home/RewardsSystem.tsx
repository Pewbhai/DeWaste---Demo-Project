import { Gem, Award, Star, Trophy } from 'lucide-react';

const RewardsSystem = () => {
  const tiers = [
    {
      icon: Gem,
      title: 'Green Starter',
      description: 'Begin your recycling journey and earn basic rewards.',
      benefits: [
        'Earn 5 tokens per kg of recyclables',
        'Access to basic recycling guides',
        'Participation in monthly draws',
      ],
      color: 'from-green-400 to-green-600',
      iconColor: 'text-green-400',
    },
    {
      icon: Award,
      title: 'Eco Enthusiast',
      description: 'Step up your recycling game with enhanced rewards.',
      benefits: [
        'Earn 10 tokens per kg of recyclables',
        'Exclusive recycling workshops',
        'Quarterly bonus rewards',
        'Partner discounts up to 10%',
      ],
      color: 'from-blue-400 to-blue-600',
      iconColor: 'text-blue-400',
    },
    {
      icon: Star,
      title: 'Sustainability Champion',
      description: 'Join our premium tier with maximum benefits.',
      benefits: [
        'Earn 15 tokens per kg of recyclables',
        'Priority verification processing',
        'Monthly bonus rewards',
        'Partner discounts up to 20%',
        'Exclusive merchandise',
      ],
      color: 'from-purple-400 to-purple-600',
      iconColor: 'text-purple-400',
    },
    {
      icon: Trophy,
      title: 'Environmental Elite',
      description: 'Our highest tier for dedicated recyclers.',
      benefits: [
        'Earn 20 tokens per kg of recyclables',
        'Instant verification processing',
        'Weekly bonus rewards',
        'Partner discounts up to 30%',
        'Exclusive NFT rewards',
        'Influence platform development',
      ],
      color: 'from-teal-400 to-teal-600',
      iconColor: 'text-teal-400',
    },
  ];

  return (
    <section id="rewards" className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Tiered Rewards System
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            The more you recycle, the more you earn. Our tiered rewards system recognizes and rewards your ongoing commitment to sustainability.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {tiers.map((tier, index) => (
            <div
              key={index}
              className="bg-white rounded-xl shadow-md overflow-hidden transition-transform hover:scale-105"
            >
              <div className={`bg-gradient-to-r ${tier.color} px-6 py-8 text-white`}>
                <tier.icon className="h-12 w-12 mb-4" />
                <h3 className="text-2xl font-bold mb-2">{tier.title}</h3>
                <p className="opacity-90">{tier.description}</p>
              </div>
              <div className="p-6">
                <h4 className="font-semibold text-gray-900 mb-4">Benefits:</h4>
                <ul className="space-y-2">
                  {tier.benefits.map((benefit, i) => (
                    <li key={i} className="flex items-start">
                      <svg
                        className={`h-5 w-5 ${tier.iconColor} mr-2 mt-0.5`}
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M5 13l4 4L19 7"
                        ></path>
                      </svg>
                      <span className="text-gray-700">{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default RewardsSystem;