import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import Button from '../ui/Button';

const Hero = () => {
  return (
    <div className="relative min-h-screen">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-r from-teal-900/80 to-green-900/80 z-10"></div>
        <img
          src="https://images.pexels.com/photos/802221/pexels-photo-802221.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
          alt="Recycling materials"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Content */}
      <div className="relative z-20 container mx-auto px-4 py-24 md:py-32 flex flex-col items-center text-center">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 max-w-4xl mx-auto leading-tight">
          Turn Your Waste Into Earnings with <span className="text-teal-400">Blockchain Technology</span>
        </h1>

        <p className="text-lg md:text-xl text-gray-100 mb-8 max-w-2xl mx-auto">
          Join our decentralized platform that rewards you for recycling. Upload proof, get verified, earn tokens. Simple, transparent, and eco-friendly.
        </p>

        <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 mb-12">
          <Link to="/auth/register">
            <Button variant="primary" size="large">
              Get Started <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
          <a href="#how-it-works">
            <Button variant="ghost" size="large">
              Learn More
            </Button>
          </a>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-4xl mt-8">
          <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl">
            <div className="text-3xl md:text-4xl font-bold text-teal-300 mb-2">25K+</div>
            <div className="text-white">Active Recyclers</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl">
            <div className="text-3xl md:text-4xl font-bold text-teal-300 mb-2">500K</div>
            <div className="text-white">Kg Waste Recycled</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl">
            <div className="text-3xl md:text-4xl font-bold text-teal-300 mb-2">$150K</div>
            <div className="text-white">Rewards Distributed</div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <a href="#how-it-works" className="text-white flex flex-col items-center">
            <span className="mb-2 text-sm font-medium">Scroll Down</span>
            <svg
              className="w-6 h-6"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M19 14l-7 7m0 0l-7-7m7 7V3"
              ></path>
            </svg>
          </a>
        </div>
      </div>
    </div>
  );
};

export default Hero;