import { useContext, useState } from 'react';
import { UserContext } from '../../context/UserContext';
import Button from '../ui/Button';
import { DollarSign, ArrowDownToLine, History, ExternalLink } from 'lucide-react';

const TokenManagement = () => {
  const { tokenBalance } = useContext(UserContext);
  const [convertAmount, setConvertAmount] = useState('');
  const [isConverting, setIsConverting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleConvert = () => {
    if (!convertAmount || parseFloat(convertAmount) <= 0 || parseFloat(convertAmount) > tokenBalance) {
      return;
    }

    setIsConverting(true);
    // Simulate conversion
    setTimeout(() => {
      setIsConverting(false);
      setShowSuccess(true);
      // Reset after success message
      setTimeout(() => {
        setShowSuccess(false);
        setConvertAmount('');
      }, 3000);
    }, 2000);
  };

  const transactions = [
    {
      id: 't1',
      date: '2025-03-15 10:30',
      type: 'Earn',
      amount: 25,
      status: 'completed',
      description: 'Recycling rewards - Plastic'
    },
    {
      id: 't2',
      date: '2025-03-10 14:45',
      type: 'Earn',
      amount: 32,
      status: 'completed',
      description: 'Recycling rewards - Glass'
    },
    {
      id: 't3',
      date: '2025-03-05 15:20',
      type: 'Convert',
      amount: -50,
      status: 'completed',
      description: 'Conversion to USDC'
    },
    {
      id: 't4',
      date: '2025-03-01 09:15',
      type: 'Earn',
      amount: 18,
      status: 'completed',
      description: 'Recycling rewards - Paper'
    },
  ];

  return (
    <div className="space-y-8">
      {/* Balance Card */}
      <div className="bg-gradient-to-r from-teal-500 to-green-500 rounded-xl shadow-md overflow-hidden">
        <div className="p-6 text-white">
          <div className="flex items-center space-x-2">
            <DollarSign className="h-8 w-8" />
            <h3 className="text-xl font-bold">Token Balance</h3>
          </div>
          <div className="mt-6 text-4xl font-bold">
            {tokenBalance} <span className="text-2xl">USDC</span>
          </div>
          <div className="mt-1 text-teal-100">
            ≈ ${tokenBalance.toFixed(2)} USD
          </div>
          <div className="mt-6 grid grid-cols-2 gap-4">
            <Button variant="white">
              <ArrowDownToLine className="w-4 h-4 mr-2" />
              Receive
            </Button>
            <Button variant="outlineWhite">
              <ExternalLink className="w-4 h-4 mr-2" />
              View on Explorer
            </Button>
          </div>
        </div>
      </div>

      {/* Convert Tokens */}
      <div className="bg-white rounded-xl shadow-sm p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">Convert Tokens to USDC</h3>
        <div className="space-y-4">
          <div>
            <label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-1">
              Amount to Convert
            </label>
            <div className="flex space-x-2">
              <input
                type="number"
                id="amount"
                value={convertAmount}
                onChange={(e) => setConvertAmount(e.target.value)}
                className="flex-1 rounded-lg border border-gray-300 shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                placeholder="Enter amount"
                min="1"
                max={tokenBalance}
                disabled={isConverting}
              />
              <Button
                variant="secondary"
                onClick={() => setConvertAmount(tokenBalance.toString())}
                disabled={tokenBalance === 0 || isConverting}
              >
                Max
              </Button>
            </div>
            <div className="mt-1 text-sm text-gray-500">
              Available: {tokenBalance} USDC
            </div>
          </div>

          {showSuccess && (
            <div className="p-3 bg-green-100 text-green-800 rounded-lg text-sm">
              Successfully converted {convertAmount} tokens to USDC!
            </div>
          )}

          <Button
            variant="primary"
            className="w-full"
            onClick={handleConvert}
            disabled={!convertAmount || parseFloat(convertAmount) <= 0 || parseFloat(convertAmount) > tokenBalance || isConverting}
          >
            {isConverting ? 'Converting...' : 'Convert to USDC'}
          </Button>
        </div>
      </div>

      {/* Transaction History */}
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center space-x-2">
            <History className="h-5 w-5 text-gray-500" />
            <h3 className="text-lg font-medium text-gray-900">Transaction History</h3>
          </div>
          <button className="text-sm text-teal-600 hover:text-teal-800 font-medium">
            View All
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Description
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Type
                </th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Amount
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {transactions.map((tx) => (
                <tr key={tx.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {tx.date}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900">
                    {tx.description}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        tx.type === 'Earn'
                          ? 'bg-green-100 text-green-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}
                    >
                      {tx.type}
                    </span>
                  </td>
                  <td className={`px-6 py-4 whitespace-nowrap text-sm font-medium text-right ${
                      tx.amount > 0 ? 'text-green-600' : 'text-blue-600'
                    }`}>
                    {tx.amount > 0 ? '+' : ''}{tx.amount} USDC
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default TokenManagement;