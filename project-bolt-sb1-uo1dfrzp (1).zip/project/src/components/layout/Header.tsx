import { useState, useContext, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Recycle, ChevronDown } from 'lucide-react';
import { AuthContext } from '../../context/AuthContext';
import Button from '../ui/Button';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const { status, user, logout } = useContext(AuthContext);
  const location = useLocation();
  const isHomePage = location.pathname === '/';

  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Define header style based on scroll and page
  const headerClasses = `fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
    isScrolled || !isHomePage
      ? 'bg-white shadow-md py-3'
      : 'bg-transparent py-5'
  }`;

  const textColor = isScrolled || !isHomePage ? 'text-teal-900' : 'text-white';
  const logoColor = isScrolled || !isHomePage ? 'text-teal-600' : 'text-white';

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  const handleLogout = () => {
    logout();
    closeMenu();
  };

  return (
    <header className={headerClasses}>
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <Recycle className={`h-8 w-8 ${logoColor}`} />
            <span className={`text-xl font-bold ${textColor}`}>DeWaste</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link
              to="/"
              className={`${textColor} hover:text-teal-500 font-medium transition-colors`}
            >
              Home
            </Link>
            {status === 'authenticated' ? (
              <>
                <Link
                  to="/dashboard"
                  className={`${textColor} hover:text-teal-500 font-medium transition-colors`}
                >
                  Dashboard
                </Link>
                <Link
                  to="/recycling"
                  className={`${textColor} hover:text-teal-500 font-medium transition-colors`}
                >
                  Recycle
                </Link>
                <Link
                  to="/wallet"
                  className={`${textColor} hover:text-teal-500 font-medium transition-colors`}
                >
                  Wallet
                </Link>
              </>
            ) : (
              <>
                <a 
                  href="#features" 
                  className={`${textColor} hover:text-teal-500 font-medium transition-colors`}
                >
                  Features
                </a>
                <a 
                  href="#rewards" 
                  className={`${textColor} hover:text-teal-500 font-medium transition-colors`}
                >
                  Rewards
                </a>
              </>
            )}
          </nav>

          {/* Auth Buttons / User Menu */}
          <div className="hidden md:flex items-center space-x-4">
            {status === 'authenticated' ? (
              <div className="relative group">
                <button 
                  className={`flex items-center space-x-2 ${textColor} font-medium`}
                >
                  <span>{user?.name}</span>
                  <ChevronDown className="h-4 w-4" />
                </button>
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                  <Link 
                    to="/profile" 
                    className="block px-4 py-2 text-sm text-gray-700 hover:bg-teal-50"
                  >
                    Profile
                  </Link>
                  <button 
                    onClick={handleLogout}
                    className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-teal-50"
                  >
                    Logout
                  </button>
                </div>
              </div>
            ) : (
              <>
                <Link to="/auth/login">
                  <Button variant="secondary">Login</Button>
                </Link>
                <Link to="/auth/register">
                  <Button variant="primary">Sign Up</Button>
                </Link>
              </>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-teal-600 p-2"
            onClick={toggleMenu}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white shadow-lg absolute top-full left-0 right-0 z-50">
          <div className="container mx-auto px-4 py-4 flex flex-col space-y-4">
            <Link
              to="/"
              className="text-teal-900 hover:text-teal-600 font-medium py-2"
              onClick={closeMenu}
            >
              Home
            </Link>
            {status === 'authenticated' ? (
              <>
                <Link
                  to="/dashboard"
                  className="text-teal-900 hover:text-teal-600 font-medium py-2"
                  onClick={closeMenu}
                >
                  Dashboard
                </Link>
                <Link
                  to="/recycling"
                  className="text-teal-900 hover:text-teal-600 font-medium py-2"
                  onClick={closeMenu}
                >
                  Recycle
                </Link>
                <Link
                  to="/wallet"
                  className="text-teal-900 hover:text-teal-600 font-medium py-2"
                  onClick={closeMenu}
                >
                  Wallet
                </Link>
                <Link
                  to="/profile"
                  className="text-teal-900 hover:text-teal-600 font-medium py-2"
                  onClick={closeMenu}
                >
                  Profile
                </Link>
                <button
                  onClick={handleLogout}
                  className="text-red-600 hover:text-red-800 font-medium py-2 text-left"
                >
                  Logout
                </button>
              </>
            ) : (
              <>
                <a 
                  href="#features" 
                  className="text-teal-900 hover:text-teal-600 font-medium py-2"
                  onClick={closeMenu}
                >
                  Features
                </a>
                <a 
                  href="#rewards" 
                  className="text-teal-900 hover:text-teal-600 font-medium py-2"
                  onClick={closeMenu}
                >
                  Rewards
                </a>
                <div className="flex flex-col space-y-2 pt-2">
                  <Link 
                    to="/auth/login" 
                    className="w-full"
                    onClick={closeMenu}
                  >
                    <Button variant="secondary" fullWidth>Login</Button>
                  </Link>
                  <Link 
                    to="/auth/register" 
                    className="w-full"
                    onClick={closeMenu}
                  >
                    <Button variant="primary" fullWidth>Sign Up</Button>
                  </Link>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;