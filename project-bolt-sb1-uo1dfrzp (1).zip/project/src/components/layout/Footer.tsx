import { Link } from 'react-router-dom';
import { Recycle, Instagram, Twitter, Facebook, Github as GitHub } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-teal-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo and Description */}
          <div className="md:col-span-1">
            <div className="flex items-center space-x-2 mb-4">
              <Recycle className="h-8 w-8" />
              <span className="text-xl font-bold">DeWaste</span>
            </div>
            <p className="text-teal-200 mb-6">
              Turning waste into earnings. A decentralized platform that rewards you for recycling and reducing waste.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-white hover:text-teal-400 transition">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-white hover:text-teal-400 transition">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-white hover:text-teal-400 transition">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-white hover:text-teal-400 transition">
                <GitHub className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-teal-200 hover:text-white transition">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/dashboard" className="text-teal-200 hover:text-white transition">
                  Dashboard
                </Link>
              </li>
              <li>
                <Link to="/recycling" className="text-teal-200 hover:text-white transition">
                  Recycle
                </Link>
              </li>
              <li>
                <Link to="/wallet" className="text-teal-200 hover:text-white transition">
                  Wallet
                </Link>
              </li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Resources</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-teal-200 hover:text-white transition">
                  Blog
                </a>
              </li>
              <li>
                <a href="#" className="text-teal-200 hover:text-white transition">
                  Recycling Guide
                </a>
              </li>
              <li>
                <a href="#" className="text-teal-200 hover:text-white transition">
                  Token Economics
                </a>
              </li>
              <li>
                <a href="#" className="text-teal-200 hover:text-white transition">
                  FAQ
                </a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact</h3>
            <ul className="space-y-2">
              <li className="text-teal-200">
                Email: support@dewaste.io
              </li>
              <li className="text-teal-200">
                Phone: +1 (555) 123-4567
              </li>
              <li className="text-teal-200">
                Address: 123 Green Street, Eco City, EC 12345
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-teal-800 mt-12 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-teal-300 text-sm mb-4 md:mb-0">
            &copy; {currentYear} DeWaste. All rights reserved.
          </p>
          <div className="flex space-x-6">
            <a href="#" className="text-teal-300 text-sm hover:text-white transition">
              Privacy Policy
            </a>
            <a href="#" className="text-teal-300 text-sm hover:text-white transition">
              Terms of Service
            </a>
            <a href="#" className="text-teal-300 text-sm hover:text-white transition">
              Cookie Policy
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;