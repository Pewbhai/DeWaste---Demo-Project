import { useState, useContext } from 'react';
import { UserContext } from '../../context/UserContext';
import { Upload, Camera, CheckCircle } from 'lucide-react';
import Button from '../ui/Button';

const materialTypes = [
  { value: 'plastic', label: 'Plastic', tokenRate: 10 },
  { value: 'paper', label: 'Paper', tokenRate: 8 },
  { value: 'glass', label: 'Glass', tokenRate: 12 },
  { value: 'metal', label: 'Metal', tokenRate: 15 },
  { value: 'electronic', label: 'Electronic Waste', tokenRate: 20 },
  { value: 'organic', label: 'Organic Waste', tokenRate: 5 },
];

const UploadForm = () => {
  const { addRecyclingActivity } = useContext(UserContext);
  const [materialType, setMaterialType] = useState('');
  const [weight, setWeight] = useState('');
  const [image, setImage] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const captureImage = () => {
    // This would be a real camera capture in a real app
    // For demo, we'll use placeholder images
    const placeholderImages = [
      'https://images.pexels.com/photos/802221/pexels-photo-802221.jpeg?auto=compress&cs=tinysrgb&w=600',
      'https://images.pexels.com/photos/5029859/pexels-photo-5029859.jpeg?auto=compress&cs=tinysrgb&w=600',
      'https://images.pexels.com/photos/5677798/pexels-photo-5677798.jpeg?auto=compress&cs=tinysrgb&w=600',
      'https://images.pexels.com/photos/6976094/pexels-photo-6976094.jpeg?auto=compress&cs=tinysrgb&w=600',
    ];
    setImage(placeholderImages[Math.floor(Math.random() * placeholderImages.length)]);
  };

  const resetForm = () => {
    setMaterialType('');
    setWeight('');
    setImage(null);
    setIsSuccess(false);
    setError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!materialType || !weight || !image) {
      setError('Please fill in all fields and upload an image.');
      return;
    }

    setError(null);
    setIsUploading(true);

    // Simulate upload delay
    setTimeout(() => {
      setIsUploading(false);
      setIsVerifying(true);

      // Simulate verification delay
      setTimeout(() => {
        setIsVerifying(false);
        const weightNum = parseFloat(weight);
        
        // Get token rate for selected material
        const material = materialTypes.find(m => m.value === materialType);
        const tokenRate = material?.tokenRate || 10;
        
        // Calculate tokens earned (weight * token rate)
        const tokensEarned = Math.round(weightNum * tokenRate);
        
        // Add activity to context
        addRecyclingActivity({
          date: new Date().toISOString(),
          type: material?.label || materialType,
          weight: weightNum,
          tokensEarned,
          status: 'verified',
          imageUrl: image,
        });
        
        setIsSuccess(true);
      }, 2000);
    }, 1500);
  };

  if (isSuccess) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-sm text-center">
        <div className="flex flex-col items-center space-y-4">
          <div className="bg-green-100 p-4 rounded-full">
            <CheckCircle className="h-12 w-12 text-green-500" />
          </div>
          <h3 className="text-2xl font-bold text-gray-800">Recycling Verified!</h3>
          <p className="text-gray-600 max-w-md">
            Your recycling activity has been verified and tokens have been added to your balance.
          </p>
          <Button variant="primary" onClick={resetForm}>
            Submit Another
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <h3 className="text-xl font-bold text-gray-900 mb-6">Upload Recycling Proof</h3>
      <form onSubmit={handleSubmit}>
        <div className="space-y-6">
          {/* Material Type Selection */}
          <div>
            <label htmlFor="materialType" className="block text-sm font-medium text-gray-700 mb-1">
              Material Type
            </label>
            <select
              id="materialType"
              value={materialType}
              onChange={(e) => setMaterialType(e.target.value)}
              className="w-full rounded-lg border border-gray-300 shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
              disabled={isUploading || isVerifying}
            >
              <option value="">Select material type</option>
              {materialTypes.map((type) => (
                <option key={type.value} value={type.value}>
                  {type.label} ({type.tokenRate} tokens/kg)
                </option>
              ))}
            </select>
          </div>

          {/* Weight Input */}
          <div>
            <label htmlFor="weight" className="block text-sm font-medium text-gray-700 mb-1">
              Weight (kg)
            </label>
            <input
              type="number"
              id="weight"
              value={weight}
              onChange={(e) => setWeight(e.target.value)}
              step="0.1"
              min="0.1"
              className="w-full rounded-lg border border-gray-300 shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
              placeholder="Enter weight in kg"
              disabled={isUploading || isVerifying}
            />
          </div>

          {/* Image Upload */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Upload Photo Proof
            </label>
            <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-lg">
              <div className="space-y-1 text-center">
                {image ? (
                  <div className="relative">
                    <img
                      src={image}
                      alt="Recycling proof"
                      className="mx-auto h-64 w-full object-cover rounded-lg"
                    />
                    <button
                      type="button"
                      onClick={() => setImage(null)}
                      className="absolute top-2 right-2 bg-red-500 text-white p-1 rounded-full hover:bg-red-600"
                      disabled={isUploading || isVerifying}
                    >
                      <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path
                          fillRule="evenodd"
                          d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </button>
                  </div>
                ) : (
                  <>
                    <Upload className="mx-auto h-12 w-12 text-gray-400" />
                    <div className="flex text-sm text-gray-600">
                      <label
                        htmlFor="file-upload"
                        className="relative cursor-pointer bg-white rounded-md font-medium text-teal-600 hover:text-teal-500 focus-within:outline-none"
                      >
                        <span>Upload a file</span>
                        <input
                          id="file-upload"
                          name="file-upload"
                          type="file"
                          className="sr-only"
                          accept="image/*"
                          onChange={handleImageChange}
                          disabled={isUploading || isVerifying}
                        />
                      </label>
                      <p className="pl-1">or drag and drop</p>
                    </div>
                    <p className="text-xs text-gray-500">PNG, JPG, GIF up to 10MB</p>
                    <div className="mt-4">
                      <Button
                        type="button"
                        variant="secondary"
                        onClick={captureImage}
                        disabled={isUploading || isVerifying}
                      >
                        <Camera className="w-4 h-4 mr-2" />
                        Take Photo
                      </Button>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>

          {error && (
            <div className="text-red-500 text-sm">{error}</div>
          )}

          <div className="flex justify-end">
            <Button
              type="submit"
              variant="primary"
              disabled={isUploading || isVerifying}
              className="w-full md:w-auto"
            >
              {isUploading ? 'Uploading...' : 
               isVerifying ? 'Verifying...' : 
               'Submit for Verification'}
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default UploadForm;