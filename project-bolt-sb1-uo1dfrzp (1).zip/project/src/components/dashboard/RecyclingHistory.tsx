import { useContext } from 'react';
import { UserContext } from '../../context/UserContext';
import { CheckCircle, Clock, XCircle } from 'lucide-react';
import { formatDistance } from 'date-fns';

const RecyclingHistory = () => {
  const { recyclingHistory } = useContext(UserContext);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'verified':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'pending':
        return <Clock className="h-5 w-5 text-yellow-500" />;
      case 'rejected':
        return <XCircle className="h-5 w-5 text-red-500" />;
      default:
        return null;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'verified':
        return 'Verified';
      case 'pending':
        return 'Pending Verification';
      case 'rejected':
        return 'Rejected';
      default:
        return '';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type.toLowerCase()) {
      case 'plastic':
        return 'bg-blue-100 text-blue-800';
      case 'paper':
        return 'bg-yellow-100 text-yellow-800';
      case 'glass':
        return 'bg-green-100 text-green-800';
      case 'metal':
        return 'bg-gray-100 text-gray-800';
      case 'electronic waste':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-teal-100 text-teal-800';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow">
      <div className="p-6 border-b border-gray-200">
        <h3 className="text-lg font-medium text-gray-900">
          Recycling History
        </h3>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Date
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Type
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Weight (kg)
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Tokens Earned
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Image
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {recyclingHistory.length > 0 ? (
              recyclingHistory.map((item) => (
                <tr key={item.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {formatDistance(new Date(item.date), new Date(), { addSuffix: true })}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getTypeColor(item.type)}`}>
                      {item.type}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {item.weight.toFixed(1)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {item.tokensEarned}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center text-sm text-gray-500">
                      <span className="mr-2">{getStatusIcon(item.status)}</span>
                      {getStatusText(item.status)}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {item.imageUrl ? (
                      <img 
                        src={item.imageUrl} 
                        alt={`Recycling proof for ${item.type}`} 
                        className="h-12 w-12 rounded-md object-cover"
                      />
                    ) : (
                      <span className="text-gray-400 text-sm">No image</span>
                    )}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={6} className="px-6 py-4 text-center text-sm text-gray-500">
                  No recycling history found. Start recycling to see your activities here.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      {recyclingHistory.length > 0 && (
        <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 text-right">
          <button className="text-sm text-teal-600 hover:text-teal-800 font-medium">
            View all recycling history
          </button>
        </div>
      )}
    </div>
  );
};

export default RecyclingHistory;