import { useContext } from 'react';
import { UserContext } from '../../context/UserContext';
import { Line } from 'react-chartjs-2';
import { 
  Chart as ChartJS, 
  CategoryScale, 
  LinearScale, 
  PointElement, 
  LineElement, 
  Title, 
  Tooltip, 
  Legend,
  Filler
} from 'chart.js';
import { format, subDays } from 'date-fns';
import { TrendingUp, Scale, CreditCard, Leaf } from 'lucide-react';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

const RecyclingStats = () => {
  const { stats, tokenBalance } = useContext(UserContext);

  // Generate last 7 days for chart
  const days = Array.from({ length: 7 }, (_, i) => {
    return format(subDays(new Date(), 6 - i), 'MMM dd');
  });

  // Sample data for the chart
  const chartData = {
    labels: days,
    datasets: [
      {
        label: 'Recycling Activity (kg)',
        data: [1.2, 0.8, 2.1, 1.6, 0.9, 3.2, 2.5],
        borderColor: 'rgb(16, 185, 129)',
        backgroundColor: 'rgba(16, 185, 129, 0.1)',
        tension: 0.4,
        fill: true,
      },
      {
        label: 'Tokens Earned',
        data: [12, 8, 21, 16, 9, 32, 25],
        borderColor: 'rgb(14, 165, 233)',
        backgroundColor: 'rgba(14, 165, 233, 0)',
        tension: 0.4,
        borderDash: [5, 5],
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      tooltip: {
        mode: 'index' as const,
        intersect: false,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      },
    },
    interaction: {
      mode: 'nearest' as const,
      axis: 'x' as const,
      intersect: false,
    },
  };

  const statCards = [
    {
      title: 'Total Recycled',
      value: `${stats.totalRecycled} kg`,
      icon: Scale,
      color: 'bg-green-50 text-green-700',
      iconColor: 'text-green-500',
    },
    {
      title: 'Total Earned',
      value: `${stats.totalEarned} USDC`,
      icon: CreditCard,
      color: 'bg-blue-50 text-blue-700',
      iconColor: 'text-blue-500',
    },
    {
      title: 'Current Balance',
      value: `${tokenBalance} USDC`,
      icon: TrendingUp,
      color: 'bg-indigo-50 text-indigo-700',
      iconColor: 'text-indigo-500',
    },
    {
      title: 'Impact Score',
      value: stats.impactScore,
      icon: Leaf,
      color: 'bg-teal-50 text-teal-700',
      iconColor: 'text-teal-500',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat, index) => (
          <div
            key={index}
            className={`${stat.color} p-6 rounded-lg shadow-sm`}
          >
            <div className="flex items-center">
              <div className={`${stat.iconColor} mr-4`}>
                <stat.icon className="h-8 w-8" />
              </div>
              <div>
                <p className="text-sm font-medium opacity-80">{stat.title}</p>
                <h3 className="text-2xl font-bold">{stat.value}</h3>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Level Progress */}
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-bold text-gray-900">Recycler Level</h3>
          <span className="text-sm text-gray-500">
            {stats.level === 1 ? 'Green Starter' : 
             stats.level === 2 ? 'Eco Enthusiast' : 
             stats.level === 3 ? 'Sustainability Champion' : 'Environmental Elite'}
          </span>
        </div>
        <div className="relative pt-1">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-teal-600 bg-teal-200">
                Level {stats.level}
              </span>
            </div>
            <div className="text-right">
              <span className="text-xs font-semibold inline-block text-teal-600">
                {Math.round((stats.totalEarned / stats.nextLevelThreshold) * 100)}%
              </span>
            </div>
          </div>
          <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-teal-200 mt-2">
            <div
              style={{ width: `${Math.min(100, (stats.totalEarned / stats.nextLevelThreshold) * 100)}%` }}
              className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-teal-500"
            ></div>
          </div>
          <div className="text-xs text-gray-500">
            {stats.totalEarned} / {stats.nextLevelThreshold} tokens to next level
          </div>
        </div>
      </div>

      {/* Activity Chart */}
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h3 className="font-bold text-gray-900 mb-4">Recent Recycling Activity</h3>
        <div className="h-64">
          <Line data={chartData} options={chartOptions} />
        </div>
      </div>
    </div>
  );
};

export default RecyclingStats;